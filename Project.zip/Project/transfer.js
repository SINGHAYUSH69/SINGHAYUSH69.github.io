 <script>
  function transferData() {
    alert('Hello World');
    var Date = document.getElementById('eventDate').value;
    var Time = document.getElementById('eventTime').value;
    var opt  = document.getElementById('eventType').value;
    var part = document.getElementById('maxParticipants').value;
    addToTable(Date,Time,opt,part);
    window.location.href = 'show.html';
  }
</script>