function submitForm() {
  // Get form values
  var email = document.getElementById('email').value;
  var password = document.getElementById('password').value;

  // Append data to the table
  var table = document.getElementById('myTable');
  var newRow = table.insertRow(table.rows.length);
  var cell1 = newRow.insertCell(0);
  var cell2 = newRow.insertCell(1);
  cell1.innerHTML = email;
  cell2.innerHTML = password;

  // Clear form fields
  document.getElementById('email').value = '';
  document.getElementById('password').value = '';
  console.log('Form Submitted');
  window.location.href='table.html';
}